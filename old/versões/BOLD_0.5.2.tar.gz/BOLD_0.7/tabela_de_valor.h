/*
    Biblioteca que guarda valores de importância para controle de dados.
    Ex: altura e largura de janelas.
*/

#ifndef TABELA_DE_VALOR_H_INCLUDED
#define TABELA_DE_VALOR_H_INCLUDED

#define ESCAPE 27
#define ENTER 10
#define SPACE 32
#define TRUE 1
#define FALSE 0

    struct _terminal_{
		int altura;
		int largura;
	}terminal;
    /*
        recebe altura e largura do terminal
    */

    struct _posicao_{
		int y;
		int x;
		int z;
	}posicao;
	/*
        recebe valores para manipulação de cursor, tanto em tela como no buffer
    */

    struct _valor_temporario_{
		int altura;
		int largura;
	}valor_temporario;
    /*
        recebe valores aleatorios de janelas para operações rápidas
    */

    WINDOW *botao_inicio;
    WINDOW *botao_abrir;
    WINDOW *barra;
    WINDOW *editor;
    WINDOW *barra_editor;
    WINDOW *check_box;

    FILE *codigo;

    char temporario[1024];
    char temporario_abertura[1024];
    char *nome_abertura;
    char *nome_arquivo;

#endif // TABELA_DE_VALOR_H_INCLUDED
