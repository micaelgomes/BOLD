#include <stdio.h>
#include <stdlib.h>
#include <stdio_ext.h>
#include <string.h>
#include <ncurses.h>
#include "tabela_de_valor.h"
#include "pseudo_css.h"
#include "editor.h"

void menu(void)
{
    int ch;//recebe do usuário a opção do menu
    int boleano; //recebe valores de menu para novo ou abrir.

    initscr();// inicia o ecrã
	start_color();//incia o gerenciamento de cores da Ncurses
    getmaxyx(stdscr, terminal.altura, terminal.largura); //pegando as dimensões do terminal
    css_home();//define as cores da home

        noecho();
        curs_set(0);
        keypad(stdscr, TRUE);
        keypad(botao_inicio, TRUE);
        keypad(botao_abrir, TRUE);


    marca();
    layout_botoes();//desenha: botoes-janelas
    selecionado(botao_inicio, botao_abrir);
    boleano = TRUE;

//execução da home ---------------------------------------------------
		do{
			ch=getch();
			if(ch == KEY_DOWN)
			{
                selecionado(botao_abrir, botao_inicio);
                boleano = FALSE;
			}

			if(ch == KEY_UP)
			{
                selecionado(botao_inicio, botao_abrir);
                boleano = TRUE;
			}

            if(ch == ENTER && boleano == TRUE)
			{
                prepara_terreno();//removendo impurezas da tela
                editor_texto();// o nome já é bem sugestivo
			}

			if(ch == ENTER && boleano == FALSE)
			{
                abrir_arquivo();
			}

    	}while(ch != ESCAPE);

	endwin();//finaliza o ecrã
	printf("Programa Finalizado!");
	puts("=====================");
    exit(2017);

    return;
}

void imprimir(char *** buffer)
{
    int i, j, k;//váriaveis de interação
    deleta_janela_string(editor);
    for(i=0;i<10;i++){
        move(2,0);
        addstr(buffer[i]);
    }

    refresh();
    return;
}

void highlight(void){

    init_pair(10, COLOR_RED, COLOR_BLACK);
    attron(COLOR_PAIR(10));
    printw("int");
    attroff(COLOR_PAIR(10));

    return;
}

void salvar_arquivo(char *** buffer)
{
    deleta_janela_string(stdscr);
    echo();
    curs_set(2);
    mvprintw(((terminal.altura)/2)-4, ((terminal.largura)/2)-19,"Insira o diretório que deseja salvar:");
    mvprintw(((terminal.altura)/2)-3, ((terminal.largura)/2)-20,"Ex: nome_pasta/nome_arquivo.tipo_arquivo ");
    move((((terminal.altura)/2)-1), (((terminal.largura)/2)-8));

    getstr(temporario);

    nome_arquivo = (char*)malloc(strlen(temporario) * sizeof(char));
    strcpy(nome_arquivo, temporario);
    //free(*temporario);

    codigo = fopen(nome_arquivo,"w");
    fprintf(codigo, "%s", buffer);
    fclose(codigo);
    return;
}

void abrir_arquivo(void)
{
    int i;
    deleta_janela_string(stdscr);
    echo();
    curs_set(2);
    mvprintw(((terminal.altura)/2)-4, ((terminal.largura)/2)-19,"Insira o diretório que deseja salvar:");
    mvprintw(((terminal.altura)/2)-3, ((terminal.largura)/2)-20,"Ex: nome_pasta/nome_arquivo.tipo_arquivo ");
    move((((terminal.altura)/2)-1), (((terminal.largura)/2)-8));

    getstr(temporario);

    nome_arquivo = (char*)malloc(strlen(temporario) * sizeof(char));
    strcpy(nome_arquivo, temporario);
    free(*temporario);

    codigo = fopen(nome_arquivo,"r");

        /*i=0;
        while((fgets(temporario_abertura, sizeof(temporario_abertura), codigo)) != NULL)
        {
            __fpurge(stdin);
            strcpy(buffer[i], temporario_abertura);
            i++;
        }*/

    fclose(codigo);

    return;
}
