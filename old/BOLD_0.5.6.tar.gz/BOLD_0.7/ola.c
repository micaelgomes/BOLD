#include <stdio.h>

int main(){
	printf("adriele");
	return 0;
}